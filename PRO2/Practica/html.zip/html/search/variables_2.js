var searchData=
[
  ['historial_98',['historial',['../classBicicleta.html#a8478220a2b0d89734674162b5477a6a2',1,'Bicicleta']]]
];
