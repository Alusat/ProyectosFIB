var searchData=
[
  ['plazas_5flibres_91',['plazas_libres',['../classEstaciones.html#aa415e6162b78a26df110962dbc109156',1,'Estaciones']]]
];
