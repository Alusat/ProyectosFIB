var searchData=
[
  ['ubicacion_98',['ubicacion',['../classBicicleta.html#ae8f5da87656d32d54eb2ed381ca520bb',1,'Bicicleta']]]
];
