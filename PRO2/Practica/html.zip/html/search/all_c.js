var searchData=
[
  ['ubi_52',['ubi',['../classBicicleta.html#abb720dbe6e84b92774674842ae0c4e96',1,'Bicicleta']]],
  ['ubicacion_53',['ubicacion',['../classBicicleta.html#ae8f5da87656d32d54eb2ed381ca520bb',1,'Bicicleta']]]
];
